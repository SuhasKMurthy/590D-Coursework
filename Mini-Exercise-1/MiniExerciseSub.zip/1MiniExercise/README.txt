Pre-requisites for the code: 
1. Install 'bokeh' package(sudo pip install bokeh). This package is used for plotting.

Even otherwise, running the python file twice should work. ;) 