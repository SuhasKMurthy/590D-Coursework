If not installed, install the following packages
	pip install mrjob
	pip install statistics

To execute the python script, on a command line 
	python Hw2MR.py -r local Email-EuAll.txt 
(Here user is assumed to be in the directory in which the python file and text file is present)

The main function contains four classes. 
Uncomment the MapReduce function to be run, and comment the rest of the lines in the 'Main' function.
